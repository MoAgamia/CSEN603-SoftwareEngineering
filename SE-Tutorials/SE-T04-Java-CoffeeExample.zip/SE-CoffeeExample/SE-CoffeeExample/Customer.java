

public class Customer {

	public void buy(Coffee cof) {
		System.out.println(cof.getCost());
		System.out.println(cof.getDescription());
	}
	
}
