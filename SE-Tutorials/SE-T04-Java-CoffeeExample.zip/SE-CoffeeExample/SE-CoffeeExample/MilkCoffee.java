

public class MilkCoffee implements Coffee {

	protected Coffee cof;
	
	public MilkCoffee(Coffee cof) {
		this.cof = cof;
	}
	
	public double getCost() {
		return cof.getCost() + 5;
	}

	public String getDescription() {
		return cof.getDescription() + " with Milk!";
	}
	
}
