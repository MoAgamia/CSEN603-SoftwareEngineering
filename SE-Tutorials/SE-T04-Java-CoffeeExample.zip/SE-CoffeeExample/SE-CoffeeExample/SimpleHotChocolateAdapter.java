
public class SimpleHotChocolateAdapter implements Coffee {

	protected HotChocolate hotChocolate;
	
	public SimpleHotChocolateAdapter(HotChocolate hotChocolate) {
		this.hotChocolate = hotChocolate;
	}
	
	public double getCost() {
		return this.hotChocolate.getCost();
	}

	public String getDescription() {
		return this.hotChocolate.getDescription();
	}
	
}
