

public class Main {

	public static void main(String[] args) {
		
		System.out.println("Hi");
		
		System.out.println("###########################################################################");
		System.out.println("#################################Decorator#################################");

		
		Coffee cof = new SimpleCoffee();
		
		System.out.println(cof.getCost());
		System.out.println(cof.getDescription());
		
		cof = new MilkCoffee(cof);
		
		System.out.println(cof.getCost());
		System.out.println(cof.getDescription());
		
		cof = new WhipCoffee(cof);
		
		System.out.println(cof.getCost());
		System.out.println(cof.getDescription());
		
		System.out.println("###########################################################################");
		System.out.println("###################################Adapter#################################");

		
		Customer cus = new Customer();
		cus.buy(cof);
		
		HotChocolate hc = new SimpleHotChocolate();
		Coffee hca = new SimpleHotChocolateAdapter(hc);
		
		cus.buy(hca);
		
		System.out.println("###########################################################################");
		System.out.println("###################################Composite###############################");

		Bill bill = new Bill();
		
		bill.addItems(cof);
		bill.addItems(hca);
		
		System.out.println(bill.getTotalBill());
		
		System.out.println("###########################################################################");
		System.out.println("###########################################################################");

		
	}
	
}
