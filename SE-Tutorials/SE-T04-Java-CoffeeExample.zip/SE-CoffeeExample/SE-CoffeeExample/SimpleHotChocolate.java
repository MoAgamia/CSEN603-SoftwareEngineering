
public class SimpleHotChocolate implements HotChocolate {

	public double getCost() {
		return 95;
	}

	public String getDescription() {
		return "Simple Hot Chocolate";
	}
	
}
