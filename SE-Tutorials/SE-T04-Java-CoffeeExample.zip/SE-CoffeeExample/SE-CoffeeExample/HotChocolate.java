

public interface HotChocolate {

	public double getCost();
    public String getDescription();
}
