

public class WhipCoffee implements Coffee {

	protected Coffee cof;
	
	public WhipCoffee(Coffee cof) {
		this.cof = cof;
	}
	
	public double getCost() {
		return cof.getCost() + 15;
	}

	public String getDescription() {
		return cof.getDescription() + " with Whip!";
	}
	
}
