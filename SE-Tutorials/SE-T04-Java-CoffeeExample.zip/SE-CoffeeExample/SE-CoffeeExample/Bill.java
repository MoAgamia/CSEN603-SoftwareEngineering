import java.util.ArrayList;

public class Bill {

	ArrayList<Coffee> billItems = new ArrayList<Coffee>();
	
	public void addItems(Coffee cof) {
		this.billItems.add(cof);
	}
	
	public double getTotalBill() {
		double totlaPrice = 0;
		
		for (Coffee cof : billItems) {
			totlaPrice += cof.getCost();
		}
		
		return totlaPrice;
	}
	
}
